let x;
let y;
let ctx;
let form;
let button;

window.onload = init;

function init() {
    c = document.getElementById('myCanvas');
    ctx = c.getContext('2d');
    form = document.getElementById('form');
    button = document.getElementById('ok');

    button.addEventListener('click', addShape);
    c.addEventListener('click', showForm);
}


//function to show the form at the co-ordinates of the click by calling remove hidden function
//setting  the form position to the top left
function showForm() {
    x = event.clientX;
    y = event.clientY;
    form.style.top =  y+'px';
    form.style.left=  x+'px';
      form.classList.remove('hidden');
}


//function set specs for the shape and pick which shape will be drawn
//using if statement to set which shape will be drawn
function addShape() {
    form.classList.add('hidden'); // hiding the form after shape has been picked
    let size = form.querySelector('input').value;
    let shape = form.querySelector('select').value;
    if (shape == 'square'){
          drawSquare(x, y, size);
      } else {
        drawCircle(x, y, size);
      }
    }

//function to draw square taking in x and y co-ordinates and size of square
//using fillstyle method to set the style
    function  drawSquare(x, y, size) {
      ctx.fillRect(x, y, size, size);
        ctx.fillStyle = "#FF0000";
    }

//function to draw circle taking in x and y co-ordinates and size
// using beginpath and moveto method to draw radiusline
//using arc method to draw the actual cirlce
     function drawCircle(x, y, size) {
        ctx.beginPath();
        ctx.moveTo(x,y);
        ctx.arc(x ,y, size, 0,Math.PI*2);
        ctx.fill();
        ctx.stroke();
    }
