let container;
let selectedBox = null;

window.onload = () => {
    window.addEventListener('mousemove', (e) => {
        if (selectedBox) {
            let x = e.clientX;
            let y = e.clientY;
            selectedBox.move(x,y);
        }
    })
    container = document.getElementById('container');
    document.getElementById('createBoxes').addEventListener('click', createBox);;

}


// function that creates box in container using random method
function createBox() {
    new Box(container, Math.random()*400, Math.random()*400);

}


class Box {
    constructor(container, x, y) {

        this.container = container;
        this.el = document.createElement('div');
        this.el.classList.add('box');
        this.el.style.top=y+'px';
        this.el.style.left=x+'px';

        this.container.appendChild(this.el);

        this.el.addEventListener('mousedown', (e) => {
            selectedBox = this; });

            this.el.addEventListener('mouseup', () => {
                selectedBox = null; });
    }

    // this method takes in position of the box and moves it around making
    // sure it does not pass boundaries of the container
    move(newX, newY) {
        let {width, height} = this.el.getBoundingClientRect();
        if (newX > 40 && newX < 500 && newY > 40 && newY < 500) {
            this.el.style.left=(newX-width)+'px';
            this.el.style.top=(newY-height)+'px';
        }

    }
}
