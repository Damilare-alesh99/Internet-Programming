
let result = 0;
const workersNumber = 10;
const workers = [];
let Counter = 0;
let workingWorkers = 10;
let lowEnd = 1;
let highEnd = 1000000;
let ARRAY = [];//array to hold 1 million numbers
for (let i = lowEnd; i <= highEnd; i++) {//looping from one to one million and pushing the numbers into array
ARRAY.push(i);
}


window.onload = () => {
    for (let x = 0; x < workersNumber; x++) {
        let worker = new Worker('Q1Worker.js');//creating a new worker
        worker.onmessage = numbersReceived;//executing numbers reeived function
        worker.postMessage(getArrayChunk(x));//send the chunk of 1000 arrays to worker
        workers.push(worker);
    }

    Counter = workersNumber;
}

//function to cut array by 1000 and send the numbers to worker
function getArrayChunk(counter) {
    let start = counter*1000;
    return ARRAY.slice(start, start+999);//slicing the array by a thousand
}

function numbersReceived(e) {//function to handle response from the worker


    if ((Counter)*1000 < ARRAY.length) {
      var x = document.getElementById("myDIV");//getting the div element mydiv from html
      x.querySelector("#count").innerHTML = (`There are ${Counter +=1} perfect squares`);//getting the header and updating the countof number of perfect squares


        e.target.postMessage(getArrayChunk(Counter))//send another array of numbers to worker
    } else {
        e.target.terminate()//if there arent any more numbers then terminate the worker
  workingWorkers -=1;//reduce one from number of working workers
  console.log(`Terminating : ${workingWorkers} workers left`)
        if (workingWorkers === 0) {// printing done in console if there are no more workers working
                      console.log("done");
        }
    }
}
