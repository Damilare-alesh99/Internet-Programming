
onmessage = (e) => {// worker taking in array of 1000 numbers

    let squareRootNumbers = 0;
    for (let n of e.data) {
        if (Math.sqrt(n) % 1 === 0) {//checking every number in array if remainder equal to 0
            squareRootNumbers += 1// if squareoot of number equal to zero then add it to count
        }
    }
    postMessage(squareRootNumbers);//sending number of perfect squares back 
}
