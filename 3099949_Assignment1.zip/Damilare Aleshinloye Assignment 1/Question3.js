let name = "alesh" ;
let counter = 1000;
let name_counter = [];
let upper = [];
let lower =[] ;


// looping through counter and  initialising name and count
for (let x = 0; x < counter; x++){
  name_counter.push({name : name + x, value : x } )
}

// to upper function to change name in lowercase to uppercase
function toUpper() {
    this.upper = array.map({
        return {name: name.toUpperCase(), value: value*5}
    });
}

// to lower function to change name in uppercase to lowercase
function toLower() {
    this.lower = array.map({
        return {name: name.toLowerCase(), value: a.value*3}
  });
