class ParagraphChanger {
    constructor(el) {
        this.el = el;
        // buttonHolder elemnt to hold buttons
        let buttonHolder = document.getElementById('buttons');


        // using 'createtextnode' method to set the name of the button to 'toggle bold'
        //event listener is then calling 'boldhandler' method to execute command
        // the command is then appended to elemnent that holds buttons
        const boldBtn = document.createElement('button');
        const boldtext = document.createTextNode('Toggle Bold');
        boldBtn.appendChild(boldtext);
        boldBtn.addEventListener('click', () => this.BoldHandler());
        buttonHolder.appendChild(boldBtn);


        // using 'createtextnode' method to set the name of the button to 'toggle position'
        //event listener is then calling 'positionhandler' method to execute command
        // the command is then appended to elemnent that holds buttons
        const positionBtn = document.createElement('button');
        const positionButton = document.createTextNode('Toggle position');
        positionBtn.appendChild(positionButton);
        positionBtn.addEventListener('click', () => this.PositionHandler());
        buttonHolder.appendChild(positionBtn);


        //bold button elemnent is created, using 'createtextnode' method to set the name of the button to 'toggle colour'
        //event listener is then calling 'colourhandler' method to execute command
        // the command is then appended to elemnent that holds buttons
        const colourBtn = document.createElement("button");
        const colourButton = document.createTextNode('Toggle colour');
        colourBtn.appendChild(colourButton);
        colourBtn.addEventListener('click', () => this.ColourHandler());
        buttonHolder.appendChild(colourBtn);


        //bold button elemnent is created, using 'createtextnode' method to set the name of the button to 'toggle size'
        //event listener is then calling 'sizehandler' method to execute command
        // the command is then appended to elemnent that holds buttons
        const sizeBtn = document.createElement('button');
        const sizeButton = document.createTextNode('Toggle size');
        sizeBtn.appendChild(sizeButton);
        sizeBtn.addEventListener('click', () => this.SizeHandler());
        buttonHolder.appendChild(sizeBtn);


    }
    // method which uses the toggle method to toggle bold according to css reference
    BoldHandler() {
    this.el.classList.toggle('bold');
    }
      // method which uses the toggle method to toggle paragraph position according to css reference
    PositionHandler() {
    this.el.classList.toggle('position');
    }
      // method which uses the toggle method to toggle paragraph colour according to css reference
    ColourHandler() {
        this.el.classList.toggle('color');
    }
      // method which uses the toggle method to toggle paragraph size according to css reference
    SizeHandler() {
      this.el.classList.toggle('size');
    }
}

window.onload = () => {
    new ParagraphChanger(document.getElementById('paragraph'));
}
