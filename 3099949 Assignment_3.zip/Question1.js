let json_object;
let container;
let name;
let button;
let fail_button
let error;

window.onload = init;

function init() {
container = document.getElementById('container');//get container from html by id
error = document.getElementById('error');//get error message from html by id
//error.classList.remove('hidden');


button = document.getElementById('Request');// get button from html by id
button.addEventListener('click', myfunction);// event listener attached to the button upon click it runs the function myfunction

fail_button = document.getElementById('failure');// get fail button from html by id
fail_button.addEventListener('click', fail_function);// event listener attached to the button upon click it runs the function fail_function

function myfunction(){
let oReq = new XMLHttpRequest();// new request method to send request to URL
//opening the request
 oReq.open("GET", 'https://courses.acs.uwinnipeg.ca/2909-051/assignments/Assignment%203/colors.php?passcode=secret');
 oReq.send();// the request is being sent to the external URL
 oReq.addEventListener('load', () => process(oReq));// event listener is set to run method taking in what was gotten from the URL as parameter
}


function fail_function(){//function which will make wrong call because of no password
let oReq = new XMLHttpRequest();// new request method to send request to URL
//opening the request without password
 oReq.open("GET", 'https://courses.acs.uwinnipeg.ca/2909-051/assignments/Assignment%203/colors.php');//
 oReq.send();// the request is being sent to the external URL
 oReq.addEventListener('load', () => process(oReq));// event listener is set to run method taking in what was gotten from the URL as parameter

}
}

function process (oReq)
{
  json_object = JSON.parse(oReq.responseText);//taking in the response in xhr and parsing it into JSON

  if (json_object.error === 0){
    name = json_object.name;//assigning the name gotten from the response to the name variable
    colour=json_object.code;//assigning the colour gotten from the response to the colour variable
    new Box(name,colour);//creating a new box with the name and colour that was parsed
    error.classList.add('hidden');//hiding the error message using hidden method after succesful call
  } else {
    error.classList.remove('hidden');//showing the error message after unsuccessful
  }
}


class Box {
      constructor(name,colour) {

          this.container = container;
          this.el = document.createElement('div');//creating div element
          this.el.classList.add('Box');
          this.el.style.backgroundColor = colour;//setting background color of box to colour passed in

          this.el.innerHTML = name;//setting name of box to the name passed in

	        let con = document.getElementById('container');//getting  the container element
          con.appendChild(this.el);//appending the box created to the container
}
}
